Recommended installation procedure:

 Type -ssc install oaxaca8, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download oaxaca8.zip.

 2. Unzip oaxaca8.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install oaxaca8, replace-.

05may2008, Ben Jann
