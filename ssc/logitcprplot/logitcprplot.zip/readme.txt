Recommended installation procedure:

 Type -ssc install logitcprplot, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download logitcprplot.zip.

 2. Unzip logitcprplot.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install logitcprplot, replace-.

28jan2009, Ben Jann
