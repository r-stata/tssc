Recommended installation procedure:

 Type -ssc install saveresults, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download saveresults.zip.

 2. Unzip saveresults.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install saveresults, replace-.

28oct2009, Ben Jann
