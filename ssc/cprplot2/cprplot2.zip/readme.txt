Recommended installation procedure:

 Type -ssc install cprplot2, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download cprplot2.zip.

 2. Unzip cprplot2.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install cprplot2, replace-.

16sep2008, Ben Jann
