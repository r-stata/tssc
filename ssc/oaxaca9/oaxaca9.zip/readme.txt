Recommended installation procedure:

 Type -ssc install oaxaca9, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download oaxaca9.zip.

 2. Unzip oaxaca9.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install oaxaca9, replace-.

30dec2009, Ben Jann
