Recommended installation procedure:

 Type -ssc install erepost, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download erepost.zip.

 2. Unzip erepost.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install erepost, replace-.

15jun2015, Ben Jann
