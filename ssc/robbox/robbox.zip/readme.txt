Recommended installation procedure:

 Type -ssc install robbox, replace- in Stata.

Alternative installation procedure (if you cannot
use -ssc- due to firewall issues, etc.):

 1. Download robbox.zip.

 2. Unzip robbox.zip into a temporary directory on
    your hard disk (e.g. c:\temp).

 3. Start Stata and type -net from c:\temp- or
    wherever you unzipped the files.

 4. Type -net install robbox, replace-.

17may2019, Ben Jann
