# stata-scheme-virdis
Implementation of the Matplolib 'viridis' color map in Stata

## Installation

Run the code below via the Stata command line.

	net install scheme_virdis, from(https://raw.github.com/vikjam/stata-scheme-virdis/master/) replace

