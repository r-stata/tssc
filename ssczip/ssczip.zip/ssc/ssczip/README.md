# ssczip
package and download Stata packages from SSC as a zip file
